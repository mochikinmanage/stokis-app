---
name: Precision Inventory System
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#3d4947'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#6d7a77'
  outline-variant: '#bcc9c6'
  surface-tint: '#006a61'
  primary: '#00685f'
  on-primary: '#ffffff'
  primary-container: '#008378'
  on-primary-container: '#f4fffc'
  inverse-primary: '#6bd8cb'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#dae2fd'
  on-secondary-container: '#5c647a'
  tertiary: '#825100'
  on-tertiary: '#ffffff'
  tertiary-container: '#a36700'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#89f5e7'
  primary-fixed-dim: '#6bd8cb'
  on-primary-fixed: '#00201d'
  on-primary-fixed-variant: '#005049'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.02em
  numeric-stat:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: -0.02em
  numeric-stat-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 0.75rem
  gutter-tablet: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system delivers a mobile-first, data-dense utility designed for warehouse staff, store managers, and inventory auditors operating on handheld devices under demanding physical conditions. The aesthetic is modern corporate minimalism with an emphasis on functional clarity, rapid legibility, and high-frequency touch interactions.

Key brand attributes:
- **Velocity:** Interfaces prioritize scan-ability with minimal cognitive friction; users capture and reconcile physical items in seconds.
- **Authority:** Crisp status indicators, unambiguous numbers, and purposeful contrast eliminate stock-taking ambiguity.
- **Refinement:** Balanced micro-radii, deliberate whitespace economy, and clean structural dividers prevent visual fatigue during long inventory sessions.

## Colors

The system uses a vibrant deep teal (`#0D9488`) as its primary operational anchor, supported by slate darks (`#0F172A`) for high-contrast structure and text. Functional status signaling relies on three strict semantic tiers:

- **Aman (Nominal):** Solid Emerald (`#10B981`) paired with tinted background (`#ECFDF5`) and subdued border (`#A7F3D0`).
- **Hampir Habis (Warning):** Amber (`#D97706`) paired with warm amber container (`#FFFBEB`) and warning border (`#FDE68A`).
- **Kritis / Discrepancy (Critical):** Crimson Rose (`#E11D48`) paired with light container (`#FFF1F2`) and alert border (`#FECDD3`).

Neutral backgrounds rely on a crisp chalk spectrum (`#F8FAFC` base page, `#FFFFFF` elevated cards, `#E2E8F0` hairline dividers) to optimize contrast under varied warehouse lighting and screen brightness levels.

## Typography

The typographical hierarchy is engineered for dense tabular lists, stock counters, and fast barcode/SKU recognition:

- **Display & Headings:** `Plus Jakarta Sans` provides geometric precision and friendly authority at top-level metrics, summary tallies, and screen titles.
- **Body & Data:** `Inter` maintains peak legibility in tabular rows, batch codes, item descriptions, and status annotations.
- **Numerical Treatment:** All SKU values, barcode numbers, batch numbers, and stock quantity inputs must enforce tabular figures (`font-feature-settings: 'tnum' on, 'cv05' on`) to ensure perfect vertical alignment across comparisons.

## Layout & Spacing

The layout is built mobile-first, calibrated around a baseline 390px viewport width (standard modern handheld), expanding responsively across tablet (768px) and desktop (1024px+).

- **Mobile Viewport (360px–428px):** A single-column vertical stack with fixed horizontal margins (`1rem` / 16px). Cards utilize full container width with tight internal padding (`space-md`).
- **Data Densification:** For operational inventory lists, items default to high-density stacked cards with right-aligned numeric stepper counters, or horizontally scrollable data lanes featuring pinned primary columns (SKU & Item Name).
- **Safe-Area Insets:** Dynamic bottom padding (`space-xl` plus `env(safe-area-inset-bottom)`) prevents bottom-navigation bars and sticky audit action sheets from obscuring the final record in long scrollable lists.

## Elevation & Depth

This system intentionally departs from heavy drop shadows to preserve clarity under bright ambient light and prevent visual smearing on lower-tier mobile displays:

- **Base Layer (Canvas):** Flat cool neutral `#F8FAFC`.
- **Level 1 (Cards, List Elements):** Flat `#FFFFFF` encapsulated by a sharp low-contrast structural border (`1px solid #E2E8F0`). No drop shadow.
- **Level 2 (Sticky Headers & Filter Rail):** `#FFFFFF` with 92% opacity and `backdrop-filter: blur(12px)`. Anchored by a crisp bottom stroke (`1px solid #CBD5E1`) and a 1px ambient feather (`0 2px 4px rgba(15, 23, 42, 0.04)`).
- **Level 3 (Modal Sheets, Scan Drawers, Sticky Audit Totals Bar):** Elevated container bordered in `#E2E8F0` with directional top shadow (`0 -8px 20px -4px rgba(15, 23, 42, 0.08)`).

## Shapes

The design uses balanced, modern radii (`roundedness: 2` / 0.5rem baseline) providing tactile affordances without wasting screen real estate:

- **Cards & Data Panels:** `8px` (`0.5rem`) for compact structural integrity.
- **Pill Tabs & Status Badges:** Fully circular (`rounded-full` / `9999px`) to immediately distinguish actionable segments and semantic badges from structural inventory cards.
- **Interactive Controls (Inputs, Stepper Buttons, Sheet Buttons):** `8px` (`0.5rem`) to maintain consistent finger-target curvature.

## Components

### Buttons & Steppers
- **Primary Operational Button:** Solid `#0D9488` background, `#FFFFFF` text, `48px` minimum height for thumb accessibility, `8px` radius. Active state: `#0F766E`.
- **Stock Audit Stepper:** Direct touch targets with a paired decrement (`-`) and increment (`+`) button minimum `40x40px`, flanking a bold numerical input field with tabular figures.

### Status Badges
- Rendered as compact pills (`height: 24px`, padding `0 10px`, font size `11px`, `font-weight: 600`).
- **Aman:** Text `#065F46`, background `#D1FAE5`, dot indicator `#10B981`.
- **Hampir Habis:** Text `#92400E`, background `#FEF3C7`, dot indicator `#F59E0B`.
- **Kritis:** Text `#9F1239`, background `#FFE4E6`, dot indicator `#E11D48`.

### Pill Tabs & Sticky Filter Bar
- **Sticky Filter Container:** Glued beneath the app bar (`top: 0` or directly under safe area). Houses horizontally scrollable chip filters with snapping behavior.
- **Filter Pills:** Inactive state features `#F1F5F9` background with `#475569` text. Active state transitions instantly to `#0D9488` background with `#FFFFFF` text and zero outline.

### Mobile Inventory Cards
- Two-column content split: Left side contains SKU, Item Title, Category Tag, and Storage Rack Location (`e.g., Bin A-12`). Right side contains current system stock versus counted physical stock, accompanied by the color-coded status badge.
- Includes a full-width micro-progress bar across the bottom rim of the card displaying recorded quantity against expected par-level.

### Horizontal Data Tables (Stacked Alternative)
- Pinned left column displaying item thumbnail/SKU. Remaining data columns (Recorded, System, Difference, Unit Cost, Actions) slide horizontally with clear scroll shadows indicating overflow.